package Config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import AppService_Utilities.PropertyLoader;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserFactory 
{
	
static WebDriver driver;
static  Browser browser;
public static PropertyLoader reader = new PropertyLoader();
	
	public static WebDriver startBrowser(String browserType) {
		
		if(browserType.equals("chrome")) {
			
			
			try (Playwright playwright = Playwright.create()) {
	        	
	    		
	            browser = playwright.chromium().launch(
	            new BrowserType.LaunchOptions().setHeadless(false));
	            
	            Page page = browser.newPage();
	         
	            
	            page.navigate(reader.getbrowserUrl());
	            System.out.println(page.title());
			}
					
			//WebDriverManager.chromedriver().setup();
			//driver = new ChromeDriver();
			
			
		}else if(browserType.equals("firefox")) {
			
			/*
			 * Playwright playwright = Playwright.create(); Browser browser =
			 * playwright.firefox().launch();
			 */
			//new BrowserType.LaunchOptions().setHeadless(false));
		
			//WebDriverManager.firefoxdriver().setup();
			//driver = new FirefoxDriver();
			
			
		}else if(browserType.equals("edge")) {
			
			/*
			 * WebDriverManager.edgedriver().setup(); driver = new EdgeDriver();
			 */
			
		}
		
		
		//driver.get(appurl);
		driver.manage().window().maximize();
		//Thread.sleep(3000);
		
		
		return driver;
		
	}
	
    
}
