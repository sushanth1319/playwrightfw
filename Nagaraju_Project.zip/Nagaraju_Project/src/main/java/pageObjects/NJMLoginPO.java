package pageObjects;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;

import AppService_Utilities.PropertyLoader;

public class NJMLoginPO {

private Page page;
	
	
	public NJMLoginPO(Page page) {
	       this.page = page;
	      
	   }
	PropertyLoader reader = new PropertyLoader();
	
	public void navigateURL() {
		
		
		page.navigate(reader.getbrowserUrl());
	}
	public void clickLogin() {
		//1st Method
		ElementHandle labelElement = page.querySelector("xpath=//label[contains(text(),'Log In')]");
		labelElement.click();
		// another Method
		page.waitForSelector("Log In");
		ElementHandle labelElement1 = page.querySelector("Log In");
        labelElement1.click();
		
	}
	public void clickAgent() {
		
		ElementHandle anchorElement = page.waitForSelector("should edit this with actual");
		anchorElement.click();
	}
	public void enterUsername() {
		page.type("#userid", reader.get_username());
	}
	public void enterPassword() {
		page.type("#password", reader.get_password());
	}
	public void clickLogin_Btn() {
		 page.waitForSelector("button");
		 ElementHandle buttonElement = page.querySelector("button.button");
         buttonElement.click();
	}
	
}
