package pageObjects;

import static org.testng.Assert.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;

public class NJMUpdatePolicyPO {
	private Page page;
	 
	public NJMUpdatePolicyPO(Page page) {
	       this.page = page;
	      
	   }

public void validateLOB() {
	String inputId = "lineofBusiness";
	String expectedText = "Businessowners";
    // Use page.locator with the ID attribute to locate the input element.
    ElementHandle inputElement = (ElementHandle) page.locator("#" + inputId).first();

    String inputValue = inputElement.inputValue();
    assertEquals(expectedText, inputValue);
        

}
public void validatePolicyNumber() {
	String inputId = "selPolicyNum";
	String expectedText = "1404595548";
    // Use page.locator with the ID attribute to locate the input element.
    ElementHandle inputElement = (ElementHandle) page.locator("#" + inputId).first();

    String inputValue = inputElement.inputValue();
    assertEquals(expectedText, inputValue, "Text content validation failed.");
        

}
	public void SelectDate() {
	Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DAY_OF_MONTH, 7); // Add 7 days to the current date.
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    String desiredDate = dateFormat.format(calendar.getTime());

    // Replace with your own date picker selector and desired date input.
    String datePickerSelector = "#datepicker-input";

    ElementHandle datePicker = (ElementHandle) page.locator(datePickerSelector).first();
    datePicker.click();

    // Type the dynamically generated date into the date picker input field.
    datePicker.type(desiredDate);
}

	public void ClickSubmit() {
		String spanId = "button-1217-btnEl";

        // Construct a CSS selector to target the <span> element by its ID.
        String submit = "span#" + spanId;

        // Use page.click() to click the <span> element.
        page.click(submit);
	}




}