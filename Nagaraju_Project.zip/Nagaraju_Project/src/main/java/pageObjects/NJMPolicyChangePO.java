package pageObjects;

import static org.testng.Assert.assertEquals;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;

public class NJMPolicyChangePO {

	
	private Page page;
	 
	public NJMPolicyChangePO(Page page) {
	       this.page = page;
	      
	   }
	
	
	public void validateInstructionalMessage() {
		String spanId = "your-span-id";
		String expectedText="";
		// Construct a CSS selector to target the <span> element by its ID.
        String spanSelector = "span#" + spanId;

        // Use page.innerText() to get the text from the <span> element.
        String spanText = page.innerText(spanSelector);
        assertEquals(expectedText, spanText);
        
	}
	public void EnterMesssage() {
		// Replace with your own div ID and textarea ID.
        String divId = "textarea-1228-inputWrap"; // ID of the <div> element.
        String textareaId = "textarea-1228-inputEl"; // ID of the <textarea> element.
        String textToEnter = "Test"; // Text to enter in the <textarea>.

        // Construct a CSS selector for the <div> element by its ID.
        String divSelector = "div#" + divId;

        // Construct a CSS selector for the <textarea> element by its ID.
        String textareaSelector = divSelector + " textarea#" + textareaId;

        // Use page.locator with the <textarea> selector to locate the <textarea> element.
        ElementHandle textareaElement = (ElementHandle) page.locator(textareaSelector).first();

		textareaElement.type(textToEnter);
	}
	
	
	public void PolicyClickSubmit() {
		String anchorId = "button-1231";

        // Construct a CSS selector to target the <a> element by its ID.
        String anchorSelector = "a#" + anchorId;

        // Use page.click() to click the <a> element.
        page.click(anchorSelector);
	}
	public void makeAnotherPolicyChange() {
		String anchorId = "button-1235";

        // Construct a CSS selector to target the <a> element by its ID.
        String anchorSelector = "a#" + anchorId;

        // Use page.click() to click the <a> element.
        page.click(anchorSelector);
	}
	public void validatePolicyScreenMessage() {
		String divId = "box-1234"; // ID of the <div> element.
        String spanStyle = "font-weight:bold"; // Style attribute value of the <span> element.

        // Construct a CSS selector for the <div> element by its ID.
        String divSelector = "div#" + divId;

        // Construct a CSS selector for the <span> element with the specific style attribute.
        String spanSelector = divSelector + " span[style='" + spanStyle + "']";

        // Use page.locator with the <span> selector to locate the <span> element.
        ElementHandle spanElement = (ElementHandle) page.locator(spanSelector).first();
	}


	
}
