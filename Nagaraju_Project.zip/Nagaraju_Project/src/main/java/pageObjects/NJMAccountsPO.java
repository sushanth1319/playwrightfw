package pageObjects;
import static org.testng.Assert.*;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.*;

public class NJMAccountsPO {
	private Page page;
 
	public NJMAccountsPO(Page page) {
	       this.page = page;
	      
	   }
	
	
	public void clickAccount() {
		 page.waitForSelector("span input[type='radio']#showAccounts-inputEl");

         // Locate the radio button element by its CSS selector
         ElementHandle radioButtonElement = page.querySelector("span input[type='radio']#showAccounts-inputEl");

         // Click the radio button
         radioButtonElement.click();
         
	}
	public void Search_BOP() {
		String inputSelector = "#textfield-1051-inputWrap input#textfield-1051-inputEl";

        // Use page.type to enter text into the input element.
        page.type(inputSelector, "bop");
        
	}
	
	public void clickAccountNumber() {
		 String xpathExpression1 =" //div[contains(@class, 'x-grid-cell-inner ')]//strong//span[contains(@class, 'blue-link')]";
		 String xpathExpression2 = "//span[text()='A427282836']";
		 String xpathExpression3 = "//span[@class='blue-link'][contains(text(),'A427282836')]";
         //Use page.waitForSelector with the XPath expression to locate the desired div.
         ElementHandle divElement = page.waitForSelector("//xpathExpression1or2or3");
         divElement.click();
         
	}
	public void textValidation() {
		String divId = "box-1172"; // Replace with the actual ID attribute value.
        String expectedText = "1404595548 (BOCT)"; // Replace with the expected text.

        // Use CSS selector to locate the div by its ID.
        String divSelector = "div#" + divId;

        ElementHandle divElement = page.waitForSelector(divSelector);

        assertNotNull(divElement, "Div element not found.");

        String divText = divElement.innerText();

        
        assertEquals("Expected Text", divText, "Text content validation failed.");
        // or 
        ElementHandle divElement2 = page.waitForSelector("//div[text()='1404595548 (BOCT)']");
        assertNotNull(divElement2, "Div element not found.");

        String divText2 = divElement.innerText();

        
        assertEquals("Expected Text", divText2, "Text content validation failed.");
    }
	
	public void clickUpdatePolicy() {
		String fullXPath = "/html/body/div[3]/div/div/div[1]/div[2]/div/div/div[5]/div[2]/div/div/div/div[1]/div/div/a[2]/span/span/span[2]";

        // Use page.locator with the full XPath expression.
        ElementHandle element = (ElementHandle) page.locator(fullXPath).first();
        if (element != null) {
            element.click(); // Click the located element.
            System.out.println("Element clicked.");
        } else {
            System.out.println("Element not found.");
        }


		
	}
	
	
}
