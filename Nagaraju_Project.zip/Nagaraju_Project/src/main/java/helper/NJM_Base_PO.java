package helper;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;


public class NJM_Base_PO {

	
	private final Page page;

    public NJM_Base_PO(Page page) {
        this.page = page;
    }

    public void click(String selector) {
        page.click(selector);
    }

    public void doubleClick(String selector) {
        page.dblclick(selector);
    }
    public void scrollToElement(String selector) {
      //  page.scrollTo(selector);
       
    }
    public void Type(String EleID, String Details) {
    	String elementId = EleID;

        String selector = "#" + elementId;

        ElementHandle element1 = page.waitForSelector(selector);
        element1.type(Details);
        
    }
    public void selectFromRadio(String valToSelect) {
    	String radioValueToSelect = valToSelect;

        String selector = "div input[type='radio'][value='" + radioValueToSelect + "']";

        page.click(selector);
    }
    public void Fill(String EleID, String Details) {
    	String elementId = EleID;

        String selector = "#" + elementId;

        ElementHandle element1 = page.waitForSelector(selector);
        element1.fill(Details);
        
    }
    public void SelectFromDropdown(String SelectorID,String ValueToSelect) {
    	String selectId = SelectorID;
        String optionTextToSelect = ValueToSelect;

        page.selectOption("#" + selectId, optionTextToSelect);
        page.waitForTimeout(2000);
    }
    

    public void scrollToTop() {
        page.evaluate("window.scrollTo(0, 0);");
    }

    public void scrollToBottom() {
        page.evaluate("window.scrollTo(0, document.body.scrollHeight);");
    }
    public void scrollDown(int px , int py) {
    	 page.evaluate("window.scrollBy(px, py)");
    }
    
    
    public void waitForSelector(String selector) {
        page.waitForSelector(selector);
    }

    public void waitForSelectorWithOptions(String selector, int timeoutMilliseconds) {
      //  PageWaitForSelectorOptions options = new PageWaitForSelectorOptions().setTimeout(timeoutMilliseconds);
       // page.waitForSelector(selector, options);
    }

    public void waitForText(String selector, String text) {
        page.waitForSelector(selector).textContent();
    }

}
