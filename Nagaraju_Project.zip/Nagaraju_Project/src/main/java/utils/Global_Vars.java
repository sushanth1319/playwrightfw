package utils;

public class Global_Vars {
    public static final int DEFAULT_EXPLICIT_TIMEOUT = 10;

    public static final String WEBDRIVER_UNIVERSITY_HOMEPAGE_URL =  "https://www.webdriveruniversity.com";
}
