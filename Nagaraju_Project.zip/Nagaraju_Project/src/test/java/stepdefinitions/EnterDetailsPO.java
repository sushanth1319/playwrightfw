package stepdefinitions;

import com.microsoft.playwright.Page;
import helper.NJM_Base_PO;

public class EnterDetailsPO {
private Page page;
private NJM_Base_PO helper;
	public EnterDetailsPO(Page page) {
	       this.page = page;
	       this.helper = new NJM_Base_PO(page);
	   }
	public void enterFirstName() {
		 helper.Type("q1", "qa");
	}
	public void enterLastName() {
         helper.Type("q2", "tester");
	}
	public void enterAddress() {
		 helper.Type("q3", "Street No 2, NewYork");
	}
	public void city() {
         helper.Type("q4", "Alabama");
	}
	public void selectStateFromDropdown() {
        helper.SelectFromDropdown("q5", "AK");
	}
	public void zipCode() {
        helper.Type("q6", "50008");
	}
	public void phoneNumber() {
        helper.Fill("q7", "744746284728");
        page.evaluate("window.scrollBy(0, 5000)");
	}
	public void enterEmail() {
        helper.Type("email", "testing@gmail.com");
	}
	public void selectReach() {
        helper.selectFromRadio("Afternoon");
        page.evaluate("window.scrollBy(0, 1000)");
	}
	public void position() {
        helper.Type("q10", "qaengineer");
	}
	public void AvailableDate() {
		
        helper.Type("q11", "30/10/2023");
	}
	public void HighestLevelofEducation() {
		helper.selectFromRadio("Graduate / Masters Degree");
	}
	public void Previous1PhoneNumber() {
        helper.Type("q27", "4736206502");
        page.evaluate("window.scrollBy(0, 1000)");
	}
	public void Previous2PhoneNumber() {
        helper.Type("q22", "473726502");
        page.setDefaultTimeout(5000);
	}
}
