package stepdefinitions;



import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;



//@RunWith(Cucumber.class)
@CucumberOptions(
		tags="@Login",
		features = {"src/test/resource/AppFeatures/login.feature"},
		glue= {"stepdefinitions"},
		dryRun = false,
		monochrome=true,
		
		//stepNotifications = true,
		//tags = "@Test3 or @Test1"
				//plugin = { "pretty", "html:target/cucumber-reports" }
				//plugin = { "pretty", "json:target/cucumber-reports/Cucumber.json"}
				//plugin = { "pretty", "junit:target/cucumber-reports/Cucumber.xml" },
		plugin = {"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
		},
		publish = true
		
		
		)		


public class MyTestRunner extends AbstractTestNGCucumberTests    {
	
	 

}






