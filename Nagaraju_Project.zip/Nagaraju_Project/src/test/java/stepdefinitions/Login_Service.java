package stepdefinitions;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import AppService_Utilities.PropertyLoader;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Login_Service 
{
	private Playwright playwright;
private Browser browser;
private BrowserContext context;
private Page page;
private playwritePO login; 
private EnterDetailsPO details;
		/*public Login_Service(playwritePO login) {
			this.login= login;
		}*/
PropertyLoader reader = new PropertyLoader();
	 @Before
	   public void setUp() {
		       playwright = Playwright.create();
		       browser = playwright.chromium().launch(
		      
			           new BrowserType.LaunchOptions().setHeadless(false));
		      context = browser.newContext();
		      page = context.newPage();
		       login = new playwritePO(page);
		       details = new EnterDetailsPO(page);
	   }
		@Given("user start home page")
		public void user_start_home_page() {
			login.navigateToURL();
			
		}
		 @When("user insert username and password")
		public void user_insert_username_and_password(){
			page.type("#user", reader.get_username());
			page.type("#pass", reader.get_password());
	}
		@Then("user click login button")
		public void user_click_login_button() {
	
			
			login.CLickLogin();
		}
		@Then("user clicks on Sample Forms")
		public void user_clicks_on_sample_forms() {
			login.clickSampleForms();
		}

		@Then("user selects Job Application Form from the Business Forms")
		public void user_selects_job_application_form_from_the_business_forms() {
			login.clickBusinessContactForm();
		}

		@Then("user enters all the required the details")
		public void user_enters_all_the_required_the_details() {
			details.enterFirstName();
			details.enterLastName();
			details.enterAddress();
			details.city();
			details.selectStateFromDropdown();
			details.zipCode();
			details.phoneNumber();
			details.enterEmail();
			details.selectReach();
			details.position();
			details.AvailableDate();
			details.HighestLevelofEducation();
			details.Previous1PhoneNumber();
			details.Previous2PhoneNumber();
		}


		@Then("user clicks on submit button")
		public void user_clicks_on_submit_button() {
			
		}
		
		@Then("user click logout")
		public void user_click_logout()  {
			//login.ClickLogout();
			
		}		
		
		
		@Then("user close browser")
		public void user_close_browser() {
			
		}
		
		@After
		   public void tearDown() {
//		       browser.close();
//		       playwright.close();
		   }
		
		
		
		
		
		
		
		
		
		
		
		
		
	
}
