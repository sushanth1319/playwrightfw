package stepdefinitions;

import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;

import AppService_Utilities.PropertyLoader;




public class playwritePO  {
	private Page page;
	
	
	public playwritePO(Page page) {
	       this.page = page;
	   }
	PropertyLoader reader = new PropertyLoader();
	
	public void navigateToURL() {
		//page.navigate("https://www.mycontactform.com/"); 
		page.navigate(reader.getbrowserUrl());
	}
	public void CLickLogin() {
		page.locator("input[name='btnSubmit']").click();
	}
	public void clickSampleForms() {
		ElementHandle sample = page.waitForSelector("a[href='https://www.mycontactform.com/samples.php']");
		sample.click();
	}
	public void clickBusinessContactForm() {
//		ElementHandle business = page.waitForSelector("a[href='https://www.mycontactform.com/samples/businesscontact.php']");
		ElementHandle business = page.waitForSelector("a[href='https://www.mycontactform.com/samples/jobapp.php']");

		business.click();
	}
	
	
	
	public void ClickLogout() {
		ElementHandle anchorElement = page.waitForSelector("a[href='https://www.mycontactform.com/panel/logout.php\']");
		anchorElement.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	public void enterUsername() {
//	page.type("#user", "qatrainer");
//
//	page.fill("#user", reader.get_username());
//}
//public void enterPassword() {
//	page.type("#pass", "admin123");
//	page.type("#pass", reader.get_password());
//	
//}
	
	
}
