package stepdefinitions;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import pageObjects.NJMAccountsPO;
import pageObjects.NJMLoginPO;
import pageObjects.NJMPolicyChangePO;
import pageObjects.NJMUpdatePolicyPO;

public class AgentUpdatePolicySteps {

	private Playwright playwright;
	private Browser browser;
	private BrowserContext context;
	private Page page;
	private NJMLoginPO loginpo;
	private NJMAccountsPO accountpo;
	private NJMUpdatePolicyPO updatepolicypo;
	private NJMPolicyChangePO policychangepo;
	@Before
	   public void setUp() {
	       playwright = Playwright.create();
	       browser = playwright.chromium().launch(
	      
		           new BrowserType.LaunchOptions().setHeadless(false));
	       context = browser.newContext();
	       page = context.newPage();
	      loginpo = new NJMLoginPO(page);
	      accountpo = new NJMAccountsPO(page);
	      updatepolicypo = new NJMUpdatePolicyPO(page);
	      policychangepo = new NJMPolicyChangePO(page);
	   }
	
	@Given("user launches NJM url")
	public void user_launches_njm_url() {
	   loginpo.navigateURL();
	   
	}

	@Then("user clicks on Log In and selects Agent")
	public void user_clicks_on_log_in_and_selects_agent() {
	    loginpo.clickLogin();
	    loginpo.clickAgent();
		
	
	}

	@Then("user enters the userID and password")
	public void user_enters_the_user_id_and_password() {
	    loginpo.enterUsername();
	    loginpo.enterPassword();
	}

	@Then("user clicks on login button")
	public void user_clicks_on_login_button() {
	    loginpo.clickLogin_Btn();
	}

	@Then("user clicks on Accounts tab from Agent Dashboard")
	public void user_clicks_on_accounts_tab_from_agent_dashboard() {
		accountpo.clickAccount();
	}

	@Then("user search and clicks on a PC Account with an Active BOP Policy")
	public void user_search_and_clicks_on_a_pc_account_with_an_active_bop_policy() {
		accountpo.Search_BOP();
		accountpo.clickAccountNumber();
	}
	@Then("user validates the policy number")
	public void user_validates_the_policy_number() {
		accountpo.textValidation();
		
	}
	@Then("user clicks on Update Policy")
	public void user_clicks_on_update_policy() {
	    accountpo.clickUpdatePolicy();
	    
	}

	@Then("user validates LOB based on the Policy Number")
	public void user_validates_lob_based_on_the_policy_number() {
		updatepolicypo.validateLOB();
	}

	@Then("user validates Policy Number")
	public void user_validates_policy_number() {
		updatepolicypo.validatePolicyNumber();
	}

	@Then("user selects a Requested Effective Date and clicks Submit")
	public void user_selects_a_requested_effective_date_and_clicks_submit() {
		updatepolicypo.SelectDate();
		updatepolicypo.ClickSubmit();
	}

	@Then("validates the instructional text displayed")
	public void validates_the_instructional_text_displayed() {
		policychangepo.validateInstructionalMessage();
	}

	@Then("user enters description of policy change")
	public void user_enters_description_of_policy_change() {
		policychangepo.EnterMesssage();
	}

	@Then("user clicks Submit and validate the success message")
	public void user_clicks_submit_and_validate_the_success_message() {
		policychangepo.PolicyClickSubmit();
	}

	@Then("user clicks on Make Another Policy Change")
	public void user_clicks_on_make_another_policy_change() {
	    
		 policychangepo.makeAnotherPolicyChange();
	}

	@Then("user validates the Update Policy screen")
	public void user_validates_the_update_policy_screen() {
		policychangepo.validatePolicyScreenMessage();
	}
	
	
	
}
