package appElements;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import AppService_Utilities.PropertyLoader;
    

public class MyContactPageObject {
	static Browser browser;
	Page page;
	 
	public void enterUserandPassword() {

	
        
//        page.locator("id=user").type("qatrainer");
//        page.locator("id=pass").type("admin123");
        
//        page.navigate(reader.get_username());
//         page.navigate(reader.get_password());
//		try (Playwright playwright = Playwright.create()) {
//        	
//    		
//            browser = playwright.chromium().launch(
//            new BrowserType.LaunchOptions().setHeadless(false));
//            
//            page = browser.newPage();
//         
//         
//		page.locator("input[name=\"user\"]").fill("qatrainer");
//		page.locator("input[name=\"pass\"]").fill("admin");
//        
//		}
	}
	public void clickLogin() {

		
	    
	        page = browser.newPage();
	        page.locator("name=btnSubmit").click();;
	        
	        
		
		}
	
	
	
}
