$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "3be4a785-4c30-444b-97ad-61055f312720",
    "feature": "User login test",
    "scenario": "verify user valid login",
    "start": 1649926695863,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1649926702285,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});